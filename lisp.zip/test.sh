:

echo "testing w python version 2"
python  lisp.py <testfact.lsp |sum

echo "testing w python version 3"
python3 lisp.py <testfact.lsp |sum

echo " The sums should match"

